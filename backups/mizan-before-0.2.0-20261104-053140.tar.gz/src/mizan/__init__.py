"""MIZAN software analysis engine."""

__version__ = "0.1.0"
